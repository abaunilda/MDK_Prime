
// Vanilla JavaScript for smooth scrolling
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Create a real logo element on page load
  const logoElement = document.querySelector('.logo img');
  const logoSvg = `
    <svg width="200" height="60" viewBox="0 0 200 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M50 35C70 25 100 20 130 30C150 35 170 35 190 25" stroke="#000" stroke-width="2"/>
      <path d="M112 40L125 37L130 42" stroke="#FF4500" stroke-width="2"/>
      <text x="40" y="55" font-family="Arial" font-weight="bold" font-size="16">TOP DETAILING</text>
    </svg>
  `;
  
  // Create a container for the SVG
  const svgContainer = document.createElement('div');
  svgContainer.innerHTML = logoSvg;
  
  // Replace the image with the SVG
  if (logoElement) {
    logoElement.parentNode.replaceChild(svgContainer.firstChild, logoElement);
  }
});
