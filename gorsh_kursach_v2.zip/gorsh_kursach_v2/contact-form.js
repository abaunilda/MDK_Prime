
document.addEventListener('DOMContentLoaded', function() {
  // Получаем все кнопки "Записаться"
  const contactButtons = document.querySelectorAll('.btn[href="#"], .service-contact-button');
  
  // Получаем форму и оверлей
  const formOverlay = document.getElementById('contact-form-overlay');
  const closeFormBtn = document.getElementById('close-form');
  
  // Добавляем обработчики для кнопок открытия формы
  contactButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      formOverlay.classList.add('active');
      document.body.style.overflow = 'hidden'; // Запрещаем скролл при открытой форме
    });
  });
  
  // Обработчик для закрытия формы по кнопке
  if (closeFormBtn) {
    closeFormBtn.addEventListener('click', closeForm);
  }
  
  // Обработчик для закрытия формы при клике на overlay
  if (formOverlay) {
    formOverlay.addEventListener('click', function(e) {
      if (e.target === formOverlay) {
        closeForm();
      }
    });
  }
  
  // Функция закрытия формы
  function closeForm() {
    formOverlay.classList.remove('active');
    document.body.style.overflow = ''; // Возвращаем скролл
  }
  
  // Валидация формы
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      let isValid = true;
      
      // Валидация имени
      const nameInput = document.getElementById('contact-name');
      if (!nameInput.value.trim()) {
        showError(nameInput, 'Пожалуйста, укажите ваше имя');
        isValid = false;
      } else {
        hideError(nameInput);
      }
      
      // Валидация телефона
      const phoneInput = document.getElementById('contact-phone');
      const phoneRegex = /^\+7\(\d{3}\) \d{3}-\d{2}-\d{2}$/;
      if (!phoneRegex.test(phoneInput.value)) {
        showError(phoneInput, 'Введите телефон в формате +7(XXX) XXX-XX-XX');
        isValid = false;
      } else {
        hideError(phoneInput);
      }
      
      // Валидация модели автомобиля
      const carInput = document.getElementById('contact-car');
      if (!carInput.value.trim()) {
        showError(carInput, 'Пожалуйста, укажите марку и модель автомобиля');
        isValid = false;
      } else {
        hideError(carInput);
      }
      
      // Валидация согласия на обработку данных
      const agreementCheckbox = document.getElementById('contact-agreement');
      const agreementError = document.querySelector('.checkbox-group .error-message');
      if (!agreementCheckbox.checked) {
        agreementError.classList.add('visible');
        isValid = false;
      } else {
        agreementError.classList.remove('visible');
      }
      
      // Если форма валидна - отправляем и показываем уведомление
      if (isValid) {
        // Здесь будет отправка формы на сервер
        // Сейчас просто имитируем успешную отправку
        
        // Показываем уведомление об успешной отправке
        showSuccessToast();
        
        // Закрываем форму
        setTimeout(closeForm, 1000);
        
        // Сбрасываем форму
        contactForm.reset();
      }
    });
  }
  
  // Маска для телефона
  const phoneInput = document.getElementById('contact-phone');
  if (phoneInput) {
    phoneInput.addEventListener('focus', function() {
      if (!phoneInput.value) {
        phoneInput.value = '+7(';
      }
    });
    
    phoneInput.addEventListener('input', function(e) {
      let value = phoneInput.value;
      value = value.replace(/\D/g, '');
      
      if (value.length > 0) {
        value = '+' + value;
      }
      
      if (value.length > 1) {
        value = value.substring(0, 2) + '(' + value.substring(2);
      }
      
      if (value.length > 6) {
        value = value.substring(0, 6) + ') ' + value.substring(6);
      }
      
      if (value.length > 11) {
        value = value.substring(0, 11) + '-' + value.substring(11);
      }
      
      if (value.length > 14) {
        value = value.substring(0, 14) + '-' + value.substring(14);
      }
      
      if (value.length > 17) {
        value = value.substring(0, 17);
      }
      
      phoneInput.value = value;
    });
  }
  
  // Функции для отображения/скрытия ошибок
  function showError(input, message) {
    input.classList.add('error');
    const errorElement = input.nextElementSibling;
    if (errorElement && errorElement.classList.contains('error-message')) {
      errorElement.textContent = message;
      errorElement.classList.add('visible');
    }
  }
  
  function hideError(input) {
    input.classList.remove('error');
    const errorElement = input.nextElementSibling;
    if (errorElement && errorElement.classList.contains('error-message')) {
      errorElement.classList.remove('visible');
    }
  }
  
  // Функция для показа уведомления об успешной отправке
  function showSuccessToast() {
    const toast = document.getElementById('success-toast');
    toast.classList.add('show');
    
    setTimeout(function() {
      toast.classList.remove('show');
    }, 5000);
  }
  
  // Добавляем анимации для элементов страницы
  addPageAnimations();
});

function addPageAnimations() {
  // Анимация для заголовков
  const titles = document.querySelectorAll('.section-title, .page-title, .hero-title');
  titles.forEach(title => {
    title.classList.add('animate-fade-in');
  });
  
  // Анимация для карточек и блоков
  const cards = document.querySelectorAll('.service-card, .why-us-card, .service-item');
  cards.forEach((card, index) => {
    card.style.animationDelay = (index * 0.15) + 's';
    card.classList.add('animate-slide-up');
  });
  
  // Анимация для форм
  const forms = document.querySelectorAll('.contact-form');
  forms.forEach(form => {
    form.classList.add('animate-slide-up');
  });
}
