
document.addEventListener('DOMContentLoaded', function () {
  // Smooth scrolling для ссылок-якорей
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();

      const targetId = this.getAttribute('href');
      if (targetId === '#') return;

      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop,
          behavior: 'smooth'
        });
      }
    });
  });

  // Выбираем все контейнеры для логотипа
  const logoContainers = document.querySelectorAll('.cont-logo');

  // Для каждого контейнера создаем и вставляем SVG-логотип
  logoContainers.forEach(container => {
    container.innerHTML = logoSvg;
  });

  // Добавляем класс active к текущей странице в навигации
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.nav-link');

  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    // Проверяем, соответствует ли href текущему пути
    if (href === currentPath ||
      (currentPath === '/' && href === '#') ||
      (currentPath === '/index.html' && href === '#')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
  // Плавная анимация для элементов при прокрутке
  function animateOnScroll() {
    const elements = document.querySelectorAll('.service-card, .why-us-card, .footer-section');

    elements.forEach(element => {
      const elementTop = element.getBoundingClientRect().top;
      const elementBottom = element.getBoundingClientRect().bottom;
      const windowHeight = window.innerHeight;

      if (elementTop < windowHeight - 100 && elementBottom > 0) {
        element.classList.add('animate-fade-in');
      }
    });
  }

  // Вызываем функцию при загрузке и при скролле
  window.addEventListener('load', animateOnScroll);
  window.addEventListener('scroll', animateOnScroll);

});


