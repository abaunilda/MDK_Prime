
document.addEventListener('DOMContentLoaded', function() {
    // Получаем все кнопки-переключатели
    const toggleButtons = document.querySelectorAll('.service-item-toggle');
    
    // Добавляем обработчики событий для каждой кнопки
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Получаем ID сервиса из атрибута data-service
            const serviceId = this.getAttribute('data-service');
            
            // Получаем соответствующий блок с деталями
            const detailsBlock = document.getElementById(`${serviceId}-details`);
            
            // Получаем иконки для этой кнопки
            const iconDown = this.querySelector('.icon-down');
            const iconUp = this.querySelector('.icon-up');
            const toggleText = this.querySelector('.toggle-text');
            
            // Проверяем, открыт ли блок с деталями
            const isActive = detailsBlock.classList.contains('active');
            
            // Если блок был открыт, закрываем его, в противном случае открываем
            if (isActive) {
                detailsBlock.classList.remove('active');
                detailsBlock.classList.add('hidden');
                iconDown.classList.remove('hidden');
                iconUp.classList.add('hidden');
                toggleText.textContent = 'Узнать подробнее';
            } else {
                detailsBlock.classList.add('active');
                detailsBlock.classList.remove('hidden');
                iconDown.classList.add('hidden');
                iconUp.classList.remove('hidden');
                toggleText.textContent = 'Свернуть';
            }
        });
    });
    
    // Добавляем атрибуты data-label для ячеек таблицы цен для мобильной версии
    const pricingTables = document.querySelectorAll('.pricing-table');
    
    pricingTables.forEach(table => {
        const headers = table.querySelectorAll('.pricing-header .pricing-cell:not(.package)');
        const rows = table.querySelectorAll('.pricing-row');
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('.pricing-cell:not(.package)');
            cells.forEach((cell, index) => {
                if (headers[index]) {
                    cell.setAttribute('data-label', headers[index].textContent);
                }
            });
        });
    });

    // Проверяем URL для автоматического открытия нужного сервиса
    const urlParams = new URLSearchParams(window.location.search);
    const serviceParam = urlParams.get('service');
    
    if (serviceParam) {
        const serviceButton = document.querySelector(`[data-service="${serviceParam}"]`);
        if (serviceButton) {
            // Имитируем клик по кнопке для открытия сервиса
            serviceButton.click();
            
            // Плавно скроллим к сервису
            setTimeout(() => {
                serviceButton.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 100);
        }
    }
});
