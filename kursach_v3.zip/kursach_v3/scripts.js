// Инициализация корзины
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Функция для сохранения корзины в localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Функция для обновления отображения корзины
function updateCart() {
    const cartItemsContainer = document.getElementById('cartItems');
    const cartCount = document.getElementById('cartCount');
    const cartTotal = document.getElementById('cartTotal');
    const cartModalEmpty = document.querySelector('.cart-modal-empty');
    const cartCountIndicator = document.getElementById('cartCountIndicator');

    // Проверяем, существуют ли необходимые элементы
    if (!cartItemsContainer || !cartCount || !cartTotal || !cartModalEmpty) {
        return;
    }

    // Очищаем контейнер
    cartItemsContainer.innerHTML = '';
    cartModalEmpty.style.display = cart.length === 0 ? 'block' : 'none';
    cartItemsContainer.style.display = cart.length === 0 ? 'none' : 'block';

    let total = 0;
    cart.forEach((item, index) => {
        const price = parseFloat(item.price.replace(' ₽', ''));
        total += price * item.quantity;

        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>${item.price} x ${item.quantity}</p>
            </div>
            <div class="cart-item-controls">
                <button class="decrease-quantity" data-index="${index}">-</button>
                <span>${item.quantity}</span>
                <button class="increase-quantity" data-index="${index}">+</button>
                <button class="remove-item" data-index="${index}">Удалить</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    });

    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    cartTotal.textContent = `${total} ₽`;
    if (cartCountIndicator) {
        cartCountIndicator.textContent = totalItems;
    }

    // Обработчики для кнопок управления корзиной
    document.querySelectorAll('.decrease-quantity').forEach(button => {
        button.addEventListener('click', () => {
            const index = button.dataset.index;
            if (cart[index].quantity > 1) {
                cart[index].quantity--;
            } else {
                cart.splice(index, 1);
            }
            saveCart();
            updateCart();
        });
    });

    document.querySelectorAll('.increase-quantity').forEach(button => {
        button.addEventListener('click', () => {
            const index = button.dataset.index;
            cart[index].quantity++;
            saveCart();
            updateCart();
        });
    });

    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', () => {
            const index = button.dataset.index;
            cart.splice(index, 1);
            saveCart();
            updateCart();
        });
    });
}

// Добавление товара в корзину
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
        const card = button.closest('.catalog-card');
        if (!card) return;
        const name = card.querySelector('h3').textContent;
        const price = card.querySelector('.price').textContent;
        const image = card.querySelector('img').src;

        const existingItem = cart.find(item => item.name === name);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ name, price, image, quantity: 1 });
        }

        saveCart();
        updateCart();

        const cartModal = document.querySelector('.cart-modal');
        if (cartModal) {
            cartModal.classList.add('open');
        }
    });
});

// Открытие/закрытие корзины
const cartButton = document.querySelector('.cart-button');
const cartModal = document.querySelector('.cart-modal');
const cartCloseButton = document.querySelector('.cart-modal-close');

if (cartButton && cartModal) {
    cartButton.addEventListener('click', () => {
        cartModal.classList.toggle('open');
        updateCart();
    });
}

if (cartCloseButton && cartModal) {
    cartCloseButton.addEventListener('click', () => {
        cartModal.classList.remove('open');
    });
}

// Обработка кнопки "Оформить заказ"
const checkoutButton = document.querySelector('.checkout-button');
const errorModal = document.getElementById('errorModal');

if (checkoutButton && errorModal) {
    checkoutButton.addEventListener('click', () => {
        errorModal.classList.add('open');
        if (cartModal) {
            cartModal.classList.remove('open'); // Закрываем корзину
        }
    });
}

// Закрытие модального окна ошибки
const errorCloseButton = document.querySelector('.error-modal-close');
if (errorCloseButton && errorModal) {
    errorCloseButton.addEventListener('click', () => {
        errorModal.classList.add('closing');
        errorModal.addEventListener('transitionend', () => {
            errorModal.classList.remove('open', 'closing');
        }, { once: true });
    });
}

// Инициализация корзины при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    updateCart();
});

// Переход на страницу авторизации по кнопке "Мои заказы"
const ordersButton = document.querySelector('.orders-button');
if (ordersButton) {
    ordersButton.addEventListener('click', () => {
        window.location.href = '/login.html';
    });
}

// Показать/скрыть пароль
function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    if (!passwordInput) return;
    const button = passwordInput.nextElementSibling;
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        button.textContent = 'Скрыть';
    } else {
        passwordInput.type = 'password';
        button.textContent = 'Показать';
    }
}

// Валидация формы авторизации
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const notification = document.getElementById('loginNotification');

        if (!email || !password) {
            notification.textContent = 'Пожалуйста, заполните все поля';
            notification.classList.add('error');
            return;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            notification.textContent = 'Пожалуйста, введите корректный email';
            notification.classList.add('error');
            return;
        }

        if (password.length < 6) {
            notification.textContent = 'Пароль должен быть не менее 6 символов';
            notification.classList.add('error');
            return;
        }

        notification.textContent = 'Авторизация успешна!';
        notification.classList.remove('error');
        notification.classList.add('success');

        if (errorModal) {
            errorModal.classList.add('open'); // Открываем модальное окно ошибки
        }
    });
}

// Валидация формы регистрации
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const notification = document.getElementById('registerNotification');

        if (!firstName || !lastName || !email || !password) {
            notification.textContent = 'Пожалуйста, заполните все поля';
            notification.classList.add('error');
            return;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            notification.textContent = 'Пожалуйста, введите корректный email';
            notification.classList.add('error');
            return;
        }

        if (password.length < 6) {
            notification.textContent = 'Пароль должен быть не менее 6 символов';
            notification.classList.add('error');
            return;
        }

        notification.textContent = 'Регистрация успешна! Перенаправляем на главную страницу...';
        notification.classList.remove('error');
        notification.classList.add('success');

        localStorage.setItem('showPromoModal', 'true');
        setTimeout(() => {
            window.location.href = '/index.html';
        }, 2000);
    });
}

// Валидация формы записи на прием
const appointmentForm = document.getElementById('appointmentForm');
if (appointmentForm) {
    appointmentForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const phone = document.getElementById('phone').value;
        const email = document.getElementById('email').value;
        const notification = document.getElementById('appointmentNotification');

        if (!name || !phone || !email) {
            notification.textContent = 'Пожалуйста, заполните все обязательные поля';
            notification.classList.add('error');
            return;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            notification.textContent = 'Пожалуйста, введите корректный email';
            notification.classList.add('error');
            return;
        }

        const phonePattern = /^\+?\d{10,15}$/;
        if (!phonePattern.test(phone)) {
            notification.textContent = 'Пожалуйста, введите корректный номер телефона';
            notification.classList.add('error');
            return;
        }

        notification.textContent = 'Заявка успешно отправлена! Мы свяжемся с вами скоро 🎉';
        notification.classList.remove('error');
        notification.classList.add('success');

        createStarsAnimation(appointmentForm);
        createConfettiAnimation(appointmentForm);

        setTimeout(() => {
            appointmentForm.reset();
            notification.textContent = '';
            notification.classList.remove('success');
        }, 3000);
    });
}

// Функция для анимации звездочек
function createStarsAnimation(container) {
    const starCount = 10;
    for (let i = 0; i < starCount; i++) {
        const star = document.createElement('div');
        star.classList.add('star');
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        star.style.animationDelay = `${Math.random() * 1}s`;
        container.appendChild(star);
        star.addEventListener('animationend', () => {
            star.remove();
        });
    }
}

// Функция для анимации конфетти
function createConfettiAnimation(container) {
    const confettiCount = 20;
    for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement('div');
        confetti.classList.add('confetti');
        confetti.style.left = `${Math.random() * 100}%`;
        confetti.style.backgroundColor = `hsl(${Math.random() * 360}, 100%, 50%)`;
        confetti.style.animationDelay = `${Math.random() * 1}s`;
        container.appendChild(confetti);
        confetti.addEventListener('animationend', () => {
            confetti.remove();
        });
    }
}

// Открытие и валидация модального окна рекламы
const promoModal = document.getElementById('promoModal');
const promoLinks = document.querySelectorAll('.promo-link');
const promoForm = document.getElementById('promoForm');
const cancelButton = document.querySelector('.cancel-button');

function closeModal() {
    if (promoModal) {
        promoModal.classList.add('closing');
        promoModal.addEventListener('animationend', () => {
            promoModal.classList.remove('open', 'closing');
            if (promoForm) {
                promoForm.reset();
                const notification = document.getElementById('promoNotification');
                if (notification) {
                    notification.textContent = '';
                    notification.classList.remove('error', 'success');
                }
            }
        }, { once: true });
    }
}

if (promoModal) {
    if (localStorage.getItem('showPromoModal') === 'true') {
        console.log('Открываем модальное окно после регистрации');
        promoModal.classList.add('open');
        localStorage.removeItem('showPromoModal');
    }

    promoLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Открываем модальное окно по клику на ссылку');
            promoModal.classList.add('open');
        });
    });

    if (cancelButton) {
        cancelButton.addEventListener('click', () => {
            console.log('Закрываем модальное окно по клику на "Отмена"');
            closeModal();
        });
    }

    if (promoForm) {
        promoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('promoEmail').value;
            const notification = document.getElementById('promoNotification');

            if (!email) {
                notification.textContent = 'Пожалуйста, введите email';
                notification.classList.add('error');
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                notification.textContent = 'Пожалуйста, введите корректный email';
                notification.classList.add('error');
                return;
            }

            notification.textContent = 'Спасибо за подписку!';
            notification.classList.remove('error');
            notification.classList.add('success');

            setTimeout(() => {
                closeModal();
            }, 2000);
        });
    }
}

// Обновленный слайдер отзывов
const reviewsSlider = document.querySelector('.reviews-slider');
if (reviewsSlider) {
    const reviewsTrack = document.querySelector('.reviews-track');
    const reviewCards = document.querySelectorAll('.review-card');
    const thumbnails = document.querySelectorAll('.thumbnail');
    const prevArrow = document.querySelector('.prev-arrow');
    const nextArrow = document.querySelector('.next-arrow');
    let currentIndex = 0;
    const cardCount = reviewCards.length / 2;
    const cardWidth = 100 / 3;

    let touchStartX = 0;
    let touchEndX = 0;

    reviewsSlider.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    });

    reviewsSlider.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        if (touchStartX - touchEndX > 50) {
            currentIndex++;
            updateSlider();
        }
        if (touchEndX - touchStartX > 50) {
            currentIndex--;
            updateSlider();
        }
    });

    function updateSlider() {
        reviewsTrack.style.transform = `translateX(-${currentIndex * cardWidth}%)`;

        thumbnails.forEach((thumbnail, index) => {
            thumbnail.classList.toggle('active', index === (currentIndex % cardCount));
        });

        if (currentIndex >= cardCount) {
            setTimeout(() => {
                reviewsTrack.style.transition = 'none';
                currentIndex = 0;
                reviewsTrack.style.transform = `translateX(0)`;
                setTimeout(() => {
                    reviewsTrack.style.transition = 'transform 0.5s ease';
                }, 50);
            }, 500);
        }

        if (currentIndex < 0) {
            setTimeout(() => {
                reviewsTrack.style.transition = 'none';
                currentIndex = cardCount - 1;
                reviewsTrack.style.transform = `translateX(-${currentIndex * cardWidth}%)`;
                setTimeout(() => {
                    reviewsTrack.style.transition = 'transform 0.5s ease';
                }, 50);
            }, 500);
        }
    }

    if (prevArrow && nextArrow) {
        prevArrow.addEventListener('click', () => {
            currentIndex--;
            updateSlider();
        });

        nextArrow.addEventListener('click', () => {
            currentIndex++;
            updateSlider();
        });
    }

    thumbnails.forEach((thumbnail, index) => {
        thumbnail.addEventListener('click', () => {
            currentIndex = index;
            updateSlider();
        });
    });

    updateSlider();
}